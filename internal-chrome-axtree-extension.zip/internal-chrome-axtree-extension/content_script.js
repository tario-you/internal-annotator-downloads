/* global chrome */
"use strict";

function pickTextFromElement(el) {
  if (!el || typeof el !== "object") return "";
  const aria = (el.getAttribute && el.getAttribute("aria-label")) || "";
  const title = (el.getAttribute && el.getAttribute("title")) || "";
  const alt = (el.getAttribute && el.getAttribute("alt")) || "";
  const text = (el.innerText || el.textContent || "").trim();
  const tag = (el.tagName || "").toLowerCase();
  const id = (el.id || "").trim();
  const cls = typeof el.className === "string" ? el.className.trim() : "";

  const label = (aria || title || alt || text || "").trim();
  const bits = [tag ? `<${tag}>` : "", id ? `#${id}` : "", cls ? `.${cls.split(/\s+/).slice(0, 3).join(".")}` : ""]
    .filter(Boolean)
    .join("");
  if (label) return `${label} ${bits}`.trim();
  return bits || tag || "";
}

function requestCapture(reason, elementText) {
  chrome.runtime.sendMessage({
    type: "capture_request",
    reason,
    url: window.location.href,
    elementText: elementText || "",
  });
}

let scrollTimer = null;
function onWheel() {
  if (scrollTimer) clearTimeout(scrollTimer);
  scrollTimer = setTimeout(() => {
    scrollTimer = null;
    requestCapture("scroll", "");
  }, 250);
}

document.addEventListener(
  "click",
  (e) => {
    const el = e && e.target;
    const text = pickTextFromElement(el);
    requestCapture("click", text);
  },
  true
);

document.addEventListener(
  "keydown",
  (e) => {
    if (!e) return;
    if (e.key === "Enter") requestCapture("enter", "");
  },
  true
);

window.addEventListener("wheel", onWheel, { passive: true });
window.addEventListener("popstate", () => requestCapture("nav", ""));
window.addEventListener("hashchange", () => requestCapture("nav", ""));

