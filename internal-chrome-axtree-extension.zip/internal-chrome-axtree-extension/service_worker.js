/* global chrome */
"use strict";

const BACKEND_ORIGIN = "http://127.0.0.1:5328";

const STORAGE_KEYS = {
  enabled: "enabled",
  lastStatus: "lastStatus",
  lastError: "lastError",
  lastSentAt: "lastSentAt",
};

const inFlight = new Set(); // tabId
const pending = new Set(); // tabId

async function storageGet(keys) {
  return await chrome.storage.local.get(keys);
}

async function storageSet(obj) {
  await chrome.storage.local.set(obj);
}

async function setStatus(status) {
  await storageSet({ [STORAGE_KEYS.lastStatus]: String(status || "") });
  chrome.runtime.sendMessage({ type: "status", status }).catch(() => {});
}

async function setError(err) {
  const msg = err instanceof Error ? err.message : String(err || "");
  await storageSet({ [STORAGE_KEYS.lastError]: msg });
  chrome.runtime.sendMessage({ type: "error", error: msg }).catch(() => {});
}

async function setSentNow() {
  await storageSet({ [STORAGE_KEYS.lastSentAt]: Date.now() });
}

function safeString(v) {
  if (typeof v === "string") return v;
  if (v == null) return "";
  return String(v);
}

async function attachDebugger(tabId) {
  return await chrome.debugger.attach({ tabId }, "1.3");
}

async function detachDebugger(tabId) {
  try {
    await chrome.debugger.detach({ tabId });
  } catch {
    // Best-effort cleanup; detach can fail if attach never succeeded.
  }
}

async function sendCommand(tabId, method, params) {
  return await chrome.debugger.sendCommand({ tabId }, method, params || {});
}

async function fetchJson(url, body) {
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const text = await res.text();
  let json = null;
  try {
    json = text ? JSON.parse(text) : null;
  } catch {
    json = null;
  }
  return { ok: res.ok, status: res.status, text, json };
}

async function captureAxTreeForTab(tabId) {
  await attachDebugger(tabId);
  try {
    // Accessibility domain commands work without explicit enable, but enabling is cheap and explicit.
    await sendCommand(tabId, "Accessibility.enable", {});
    const full = await sendCommand(tabId, "Accessibility.getFullAXTree", {});
    return full;
  } finally {
    await detachDebugger(tabId);
  }
}

async function pushToBackend({ url, axTree, elementText }) {
  const appendHtmlUrl = `${BACKEND_ORIGIN}/api/browser/append_html`;
  const appendElementUrl = `${BACKEND_ORIGIN}/api/browser/append_element`;

  const htmlPayload = {
    data: {
      // Keep this minimal; we only need URL + AX tree.
      html: "",
      url: safeString(url),
      // Backend expects a JSON string and will json.loads() it.
      dom: "[]",
    },
    // Backend persists this under "axtree" in html.jsonl entries.
    pageAxTree: axTree,
  };

  const htmlRes = await fetchJson(appendHtmlUrl, htmlPayload);
  if (!htmlRes.ok) {
    const detail =
      (htmlRes.json && typeof htmlRes.json.message === "string" && htmlRes.json.message) ||
      htmlRes.text ||
      `HTTP ${String(htmlRes.status)}`;
    throw new Error(`append_html failed: ${detail}`);
  }

  if (elementText && safeString(elementText).trim()) {
    const elementPayload = {
      data: {
        text: safeString(elementText).trim().slice(0, 280),
        url: safeString(url),
      },
    };
    const elRes = await fetchJson(appendElementUrl, elementPayload);
    if (!elRes.ok) {
      const detail =
        (elRes.json && typeof elRes.json.message === "string" && elRes.json.message) ||
        elRes.text ||
        `HTTP ${String(elRes.status)}`;
      throw new Error(`append_element failed: ${detail}`);
    }
  }
}

async function runCapture({ tabId, url, elementText, reason }) {
  if (!Number.isInteger(tabId) || tabId <= 0) throw new Error("Missing tabId");

  const { enabled } = await storageGet([STORAGE_KEYS.enabled]);
  if (enabled !== true) return;

  if (inFlight.has(tabId)) {
    pending.add(tabId);
    return;
  }

  inFlight.add(tabId);
  try {
    await setStatus(`Capturing AX tree (${safeString(reason) || "event"})...`);
    const axTree = await captureAxTreeForTab(tabId);
    await setStatus("Sending to annotator backend...");
    await pushToBackend({ url, axTree, elementText });
    await setSentNow();
    await setStatus("Sent.");
    await storageSet({ [STORAGE_KEYS.lastError]: "" });
  } catch (err) {
    await setStatus("Error.");
    await setError(err);
  } finally {
    inFlight.delete(tabId);
    if (pending.has(tabId)) {
      pending.delete(tabId);
      // Re-run once to coalesce bursts into a single follow-up capture.
      await runCapture({ tabId, url, elementText, reason: "coalesced" });
    }
  }
}

chrome.runtime.onInstalled.addListener(async () => {
  const cur = await storageGet([STORAGE_KEYS.enabled]);
  if (cur.enabled !== true && cur.enabled !== false) {
    await storageSet({ [STORAGE_KEYS.enabled]: false });
  }
});

chrome.runtime.onMessage.addListener((msg, sender) => {
  const type = msg && msg.type;
  if (type === "capture_request") {
    const tabId = sender && sender.tab && sender.tab.id;
    const url = safeString(msg.url || (sender.tab && sender.tab.url));
    const elementText = safeString(msg.elementText || "");
    const reason = safeString(msg.reason || "");
    runCapture({ tabId, url, elementText, reason });
  }
});

