/* global chrome */
"use strict";

const STORAGE_KEYS = {
  enabled: "enabled",
  lastStatus: "lastStatus",
  lastError: "lastError",
  lastSentAt: "lastSentAt",
};

function $(id) {
  return document.getElementById(id);
}

function fmtTime(ts) {
  if (!ts || typeof ts !== "number") return "—";
  try {
    const d = new Date(ts);
    return d.toLocaleString();
  } catch {
    return "—";
  }
}

async function refresh() {
  const data = await chrome.storage.local.get([
    STORAGE_KEYS.enabled,
    STORAGE_KEYS.lastStatus,
    STORAGE_KEYS.lastError,
    STORAGE_KEYS.lastSentAt,
  ]);

  $("enabled").checked = data.enabled === true;
  $("status").textContent = data.lastStatus ? String(data.lastStatus) : "—";
  $("lastSent").textContent = fmtTime(data.lastSentAt);

  const err = (data.lastError || "").trim();
  if (err) {
    $("error").style.display = "block";
    $("error").textContent = err;
  } else {
    $("error").style.display = "none";
    $("error").textContent = "";
  }
}

async function setEnabled(enabled) {
  await chrome.storage.local.set({ [STORAGE_KEYS.enabled]: enabled === true });
  await refresh();
}

async function clearError() {
  await chrome.storage.local.set({ [STORAGE_KEYS.lastError]: "" });
  await refresh();
}

async function captureNow() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const tab = tabs && tabs[0];
  if (!tab || !tab.id) return;
  chrome.tabs.sendMessage(tab.id, { type: "capture_request", reason: "manual", url: tab.url || "" });
  window.close();
}

document.addEventListener("DOMContentLoaded", async () => {
  $("enabled").addEventListener("change", (e) => setEnabled(e.target.checked));
  $("clear").addEventListener("click", clearError);
  $("capture").addEventListener("click", captureNow);

  chrome.runtime.onMessage.addListener(() => {
    refresh().catch(() => {});
  });

  await refresh();
});

